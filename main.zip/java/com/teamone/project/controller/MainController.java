package com.teamone.project.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.teamone.project.command.BCommand;
import com.teamone.project.command.main.JoinForm;
import com.teamone.project.command.main.MainPage;
import com.teamone.project.command.main.WeatherPage;

@Controller
public class MainController {
	BCommand command;
	
	@RequestMapping("/main")
	public String index(Model model){
		System.out.println("main");
		command = new MainPage();
		command.execute(model);
		
		return "main";
	}
	
	@RequestMapping("/weather")
	public String weather(Model model){
		System.out.println("weather");
		command = new WeatherPage();
		command.execute(model);
		
		return "weather";
	}
	
	@RequestMapping("/joinform")
	public String joinform(Model model){
		System.out.println("joinform");
		command = new JoinForm();
		command.execute(model);
		
		return "memberJoin";
	}
}
