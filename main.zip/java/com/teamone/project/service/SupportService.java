package com.teamone.project.service;

import java.sql.SQLException;
import java.util.List;
import com.teamone.project.model.SupportModel;

public interface SupportService {
   
	int regSupport(SupportModel model) throws SQLException;
	List<SupportModel> getSupportList() throws SQLException;
	int updateSupport(SupportModel model) throws SQLException;
	int delSupport(int num) throws SQLException;
	List<SupportModel> searchSupport(String keyword) throws SQLException;
	SupportModel getSelectByNum(int num) throws SQLException;
	List<SupportModel> getMenuList(String kinds) throws SQLException;
	
	
	
/*    int regContent(Map<String, Object> paramMap);   
    int getContentCnt(Map<String, Object> paramMap);     
    List<Board> getContentList(Map<String, Object> paramMap);     
    Board getContentView(Map<String, Object> paramMap);     
    int regReply(Map<String, Object> paramMap);     
    List<BoardReply> getReplyList(Map<String, Object> paramMap);     
    int delReply(Map<String, Object> paramMap);     
    int getBoardCheck(Map<String, Object> paramMap);     
    int delBoard(Map<String, Object> paramMap);*/
}
