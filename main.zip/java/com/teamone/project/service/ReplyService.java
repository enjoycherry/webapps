package com.teamone.project.service;

import java.sql.SQLException;
import java.util.List;
import com.teamone.project.model.ReplyModel;

public interface ReplyService {
	
	List<ReplyModel> getAllReply() throws SQLException;
	int regReply(ReplyModel model) throws SQLException;
	int getReadCount(String num) throws SQLException;
	ReplyModel getReplyDetailsByNum(String num) throws SQLException;
	int updateReply(ReplyModel model) throws SQLException;
	ReplyModel checkPassWord(String pass, String num) throws SQLException;
	int delReply(String num) throws SQLException;
	List<ReplyModel> getReplyList() throws SQLException;
	
	
/*    int regContent(Map<String, Object> paramMap);   
    int getContentCnt(Map<String, Object> paramMap);     
    List<Board> getContentList(Map<String, Object> paramMap);     
    Board getContentView(Map<String, Object> paramMap);     
    int regReply(Map<String, Object> paramMap);     
    List<BoardReply> getReplyList(Map<String, Object> paramMap);     
    int delReply(Map<String, Object> paramMap);     
    int getBoardCheck(Map<String, Object> paramMap);     
    int delBoard(Map<String, Object> paramMap);*/
}
