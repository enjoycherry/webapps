package com.teamone.project.service.impl;

import javax.annotation.Resource;
import org.springframework.stereotype.Service;

import com.teamone.project.dao.MemberDAO;
import com.teamone.project.model.MemberModel;
import com.teamone.project.service.MemberService;

@Service("memberService")
public class MemberServiceImpl implements MemberService{

	@Resource(name="memberDAO")
	private MemberDAO memberDAO;

	@Override
	public int checkUser(String userid, String pwd) {
		return memberDAO.checkUser(userid, pwd);
	}

	@Override
	public MemberModel getMemberList(String userid) {
		return memberDAO.getMemberList(userid);
	}

	@Override
	public int conrfirmMember(String userid) {
		return memberDAO.conrfirmMember(userid);
	}

	@Override
	public int regMember(MemberModel model) {
		return memberDAO.regMember(model);
	}

	@Override
	public int updateMember(MemberModel model) {
		return memberDAO.updateMember(model);
	}
	
	

}
