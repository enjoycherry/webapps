package com.teamone.project.service.impl;

import java.util.List;

import javax.annotation.Resource;
import org.springframework.stereotype.Service;

import com.teamone.project.dao.ReplyDAO;
import com.teamone.project.model.ReplyModel;
import com.teamone.project.service.ReplyService;

@Service("replyService")
public class ReplyServiceImpl implements ReplyService{

	@Resource(name="replyServiceDAO")
	private ReplyDAO replyDAO;

	@Override
	public List<ReplyModel> getAllReply() {
		return replyDAO.getAllReply();
	}

	@Override
	public int regReply(ReplyModel model) {
		return replyDAO.regReply(model);
	}

	@Override
	public int getReadCount(String num) {
		return replyDAO.getReadCount(num);
	}

	@Override
	public ReplyModel getReplyDetailsByNum(String num) {
		return replyDAO.getReplyDetailsByNum(num);
	}

	@Override
	public int updateReply(ReplyModel model) {
		return replyDAO.updateReply(model);
	}

	@Override
	public ReplyModel checkPassWord(String pass, String num) {
		return replyDAO.checkPassWord(pass, num);
	}

	@Override
	public int delReply(String num) {
		return replyDAO.delReply(num);
	}

	@Override
	public List<ReplyModel> getReplyList() {
		return replyDAO.getReplyList();
	}

}
