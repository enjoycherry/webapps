package com.teamone.project.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.teamone.project.dao.ClientProfileDAO;
import com.teamone.project.model.ClientProfileModel;
import com.teamone.project.service.ClientProfileService;

@Service("clientProfileService")
public class ClientProfileServiceImpl implements ClientProfileService{

	@Resource(name="clientProfileDAO")
	private ClientProfileDAO clientProfileDAO;
	
	@Override
	public int regClientProfile(ClientProfileModel model) {		
		return clientProfileDAO.regClientProfile(model);
	}
	

}
