package com.teamone.project.service.impl;

import java.util.List;

import javax.annotation.Resource;
import org.springframework.stereotype.Service;

import com.teamone.project.dao.MessageDAO;
import com.teamone.project.model.MessageModel;
import com.teamone.project.service.MessageService;

@Service("messageService")
public class MessageServiceImpl implements MessageService{
	@Resource(name="memssDAO")
	private MessageDAO messageDAO;
	
	@Override
	public int regMessage(MessageModel model) {
		return messageDAO.regMessage(model);
	}

	@Override
	public List<MessageModel> getSentMessage(String id) {
		return messageDAO.getSentMessage(id);
	}

	@Override
	public List<MessageModel> getMyMessage(String id) {
		return messageDAO.getMyMessage(id);
	}

	@Override
	public MessageModel getReadMessage(int num) {
		return messageDAO.getReadMessage(num);
	}

	@Override
	public int updateReadMessage(int num) {
		return messageDAO.updateReadMessage(num);
	}

	@Override
	public int getUnreadMessageCount(String id) {
		return messageDAO.getUnreadMessageCount(id);
	}

	@Override
	public List<MessageModel> getUnreadMessageList(String id) {
		return messageDAO.getUnreadMessageList(id);
	}

	@Override
	public List<MessageModel> getUnOpenedMessageList(String id, String readnot) {
		return messageDAO.getUnOpenedMessageList(id, readnot);
	}

	@Override
	public int updateTrashMessage(int num) {
		return messageDAO.updateTrashMessage(num);
	}

	@Override
	public List<MessageModel> getTrashedMessage() {
		return messageDAO.getTrashedMessage();
	}

	@Override
	public int updateRecoveryMessage(int num) {
		return messageDAO.updateRecoveryMessage(num);
	}

	@Override
	public int deleteMessage(int num) {
		return messageDAO.deleteMessage(num);
	}

	@Override
	public int deleteAllMessages(int num) {
		return messageDAO.deleteAllMessages(num);
	}

	@Override
	public List<MessageModel> getKeptMessageList() {
		return messageDAO.getKeptMessageList();
	}
}
