package com.teamone.project.service.impl;

import javax.annotation.Resource;
import org.springframework.stereotype.Service;

import com.teamone.project.service.RequestService;



@Service("clientProfileService")
public class RequestServiceImpl implements RequestService{

//	@Resource(name="requestDAO")
//	private RequestDAO requestDAO;
	
}
