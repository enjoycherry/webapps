package com.teamone.project.service.impl;

import java.util.List;
import javax.annotation.Resource;
import org.springframework.stereotype.Service;

import com.teamone.project.dao.MyPageDAO;
import com.teamone.project.model.MyPageModel;
import com.teamone.project.service.MyPageService;

@Service("myPageService")
public class MyPageServiceImpl implements MyPageService{

	@Resource(name="myPageDAO")
	private MyPageDAO myPageDAO;

	@Override
	public MyPageModel getMyProfile(String id) {
		return myPageDAO.getMyProfile(id);
	}

	@Override
	public List<MyPageModel> getReplyList(String id) {
		return myPageDAO.getReplyList(id);
	}	
}
