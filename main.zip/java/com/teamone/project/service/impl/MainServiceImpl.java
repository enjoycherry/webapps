package com.teamone.project.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.teamone.project.dao.MainDAO;
import com.teamone.project.model.MainModel;
import com.teamone.project.service.MainService;

@Service("mainService")
public class MainServiceImpl implements MainService{

	@Resource(name="mainDAO")
	private MainDAO mainDAO;

	@Override
	public List<MainModel> getNewList() {		
		return mainDAO.getNewList();
	}
	


}
