package com.teamone.project.service.impl;

import java.util.List;

import javax.annotation.Resource;
import org.springframework.stereotype.Service;

import com.teamone.project.dao.TransProfileDAO;
import com.teamone.project.model.TransJobModel;
import com.teamone.project.model.TransProfileModel;
import com.teamone.project.service.TransProfileService;

@Service("transProfileService")
public class TransProfileServiceImpl implements TransProfileService{

	@Resource(name="transProfileDAO")
	private TransProfileDAO transProfileDAO;

	@Override
	public int regTransProfiles(TransProfileModel model) {
		return transProfileDAO.regTransProfiles(model);
	}

	@Override
	public List<TransProfileModel> getTransProfileList() {
		return transProfileDAO.getTransProfileList();
	}

	@Override
	public TransProfileModel getTransProfileListByNum(int num) {
		return transProfileDAO.getTransProfileListByNum(num);
	}

	@Override
	public TransProfileModel getTransProfileListById(String id) {
		return transProfileDAO.getTransProfileListById(id);
	}

	@Override
	public TransProfileModel getTransProfileListByCode(int code) {
		return transProfileDAO.getTransProfileListByCode(code);
	}

	@Override
	public int updateTransProfile(TransProfileModel model) {
		return transProfileDAO.updateTransProfile(model);
	}

	@Override
	public List<TransJobModel> getJobList() {
		return transProfileDAO.getJobList();
	}

	@Override
	public List<TransProfileModel> searchTransProfile(String keyword) {
		return transProfileDAO.searchTransProfile(keyword);
	}
}
