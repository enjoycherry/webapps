package com.teamone.project.service.impl;

import javax.annotation.Resource;
import org.springframework.stereotype.Service;

import com.teamone.project.service.TransJobService;


@Service("transJobService")
public class TransJobServiceImpl implements TransJobService{

//	@Resource(name="transJobDAO")
//	private TransJobDAO transJobDAO;
	

}
