package com.teamone.project.service.impl;

import java.util.List;
import javax.annotation.Resource;
import org.springframework.stereotype.Service;

import com.teamone.project.dao.WeatherDAO;
import com.teamone.project.model.WeatherModel;
import com.teamone.project.service.WeatherService;

@Service("weatherService")
public class WeatherServiceImpl implements WeatherService{

	@Resource(name="weatherDAO")
	private WeatherDAO weatherDAO;

	@Override
	public int regWeather(WeatherModel model) {
		return weatherDAO.regWeather(model);
	}

	@Override
	public int delWeather() {
		return weatherDAO.delWeather();
	}

	@Override
	public List<WeatherModel> getWeather() {
		return weatherDAO.getWeather();
	}	
}