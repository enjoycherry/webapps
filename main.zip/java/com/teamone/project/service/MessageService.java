package com.teamone.project.service;

import java.sql.SQLException;
import java.util.List;
import com.teamone.project.model.MessageModel;


public interface MessageService {	
	int regMessage(MessageModel model) throws SQLException;
	List<MessageModel> getSentMessage(String id) throws SQLException;
	List<MessageModel> getMyMessage(String id) throws SQLException;
	MessageModel getReadMessage(int num) throws SQLException;
	int updateReadMessage(int num) throws SQLException;
	int getUnreadMessageCount(String id) throws SQLException;
	List<MessageModel> getUnreadMessageList(String id) throws SQLException;
	List<MessageModel> getUnOpenedMessageList(String id, String readnot) throws SQLException;
	int updateTrashMessage(int num) throws SQLException;
	List<MessageModel> getTrashedMessage() throws SQLException;
	int updateRecoveryMessage(int num) throws SQLException;
	int deleteMessage(int num) throws SQLException;
	int deleteAllMessages(int num) throws SQLException;
	List<MessageModel> getKeptMessageList() throws SQLException;
	
/*    int regContent(Map<String, Object> paramMap);   
    int getContentCnt(Map<String, Object> paramMap);     
    List<Board> getContentList(Map<String, Object> paramMap);     
    Board getContentView(Map<String, Object> paramMap);     
    int regReply(Map<String, Object> paramMap);     
    List<BoardReply> getReplyList(Map<String, Object> paramMap);     
    int delReply(Map<String, Object> paramMap);     
    int getBoardCheck(Map<String, Object> paramMap);     
    int delBoard(Map<String, Object> paramMap);*/
}
