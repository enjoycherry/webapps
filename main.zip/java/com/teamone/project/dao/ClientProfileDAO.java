package com.teamone.project.dao;

import com.teamone.project.model.ClientProfileModel;

public interface ClientProfileDAO  {
	int regClientProfile(ClientProfileModel model);
	
}
