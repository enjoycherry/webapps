package com.teamone.project.dao;

import java.util.List;
import com.teamone.project.model.WeatherModel;

public interface WeatherDAO {
	int regWeather(WeatherModel model);
	int delWeather();
	List<WeatherModel> getWeather();
}
