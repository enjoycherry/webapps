package com.teamone.project.dao;

import java.util.List;
import com.teamone.project.model.MainModel;

public interface MainDAO {
	List<MainModel> getNewList();
}
