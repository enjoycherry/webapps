package com.teamone.project.dao.impl;

import java.util.HashMap;
import java.util.List;
import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.teamone.project.dao.MessageDAO;
import com.teamone.project.model.MessageModel;

@Repository("message")
public class MessageDAOImpl implements MessageDAO {

	@Inject
	private SqlSession sqlSession;
	
	public void setSqlSession(SqlSession sqlSession){
        this.sqlSession = sqlSession;
    }

	@Override
	public int regMessage(MessageModel model) {
		return sqlSession.insert("insertMessage", model);
	}

	@Override
	public List<MessageModel> getSentMessage(String id) {
		return sqlSession.selectList("selectSentMessage", id);
	}

	@Override
	public List<MessageModel> getMyMessage(String id) {
		return sqlSession.selectList("selectMyMessage", id);
	}

	@Override
	public MessageModel getReadMessage(int num) {
		return sqlSession.selectOne("selectReadMessage", num);
	}

	@Override
	public int updateReadMessage(int num) {
		return sqlSession.update("updateReadMessage", num);
	}

	@Override
	public int getUnreadMessageCount(String id) {
		return sqlSession.selectOne("selectUnreadMessageCount", id);
	}

	@Override
	public List<MessageModel> getUnreadMessageList(String id) {
		return sqlSession.selectList("selectUnreadMessageList", id);
	}

	@Override
	public List<MessageModel> getUnOpenedMessageList(String id, String readnot) {
		HashMap<String, String> map = new HashMap<>();
		map.put("id", id);
		map.put("readnot", readnot);		
		return sqlSession.selectList("selectUnOpenedMessageList", map);
	}

	@Override
	public int updateTrashMessage(int num) {
		return sqlSession.update("updateTrashMessage", num);
	}

	@Override
	public List<MessageModel> getTrashedMessage() {
		return sqlSession.selectList("selectTrashedMessage");
	}

	@Override
	public int updateRecoveryMessage(int num) {
		return sqlSession.update("updateRecoveryMessage", num);
	}

	@Override
	public int deleteMessage(int num) {
		return sqlSession.delete("delMessage", num);
	}

	@Override
	public int deleteAllMessages(int num) {
		return sqlSession.delete("delAllMessage", num);
	}

	@Override
	public List<MessageModel> getKeptMessageList() {
		return sqlSession.selectList("selectKeptMessageList");
	}	
}
