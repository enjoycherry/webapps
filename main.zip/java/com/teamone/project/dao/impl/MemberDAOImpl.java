package com.teamone.project.dao.impl;

import java.util.HashMap;
import javax.inject.Inject;
import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.teamone.project.dao.MemberDAO;
import com.teamone.project.model.MemberModel;

@Repository("member")
public class MemberDAOImpl implements MemberDAO {

	@Inject
	private SqlSession sqlSession;
	
	public void setSqlSession(SqlSession sqlSession){
        this.sqlSession = sqlSession;
    }

	@Override
	public int checkUser(String userid, String pwd) {
		int result;
		HashMap<String, String> map = new HashMap<>();
		map.put("userid", userid);
		map.put("pwd", pwd);
		MemberModel memberModel = sqlSession.selectOne("checkUserList", map);
		if(memberModel!=null){
			result = 1;
		} else{
			result = 0;
		}
		return result;
	}

	@Override
	public MemberModel getMemberList(String userid) {		
		return sqlSession.selectOne("selectMemberView", userid);
	}

	@Override
	public int conrfirmMember(String userid) {
		int result;
		String member = sqlSession.selectOne("conrfirmMember", userid);
		if(member!=null){
			result = 1;
		} else{
			result = -1;
		}
		return result;
	}

	@Override
	public int regMember(MemberModel model) {		
		return sqlSession.insert("insertMembers", model);
	}

	@Override
	public int updateMember(MemberModel model) {		
		return sqlSession.update("updateMember", model);
	}	
}
