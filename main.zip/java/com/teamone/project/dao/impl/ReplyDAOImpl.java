package com.teamone.project.dao.impl;

import java.util.HashMap;
import java.util.List;

import javax.inject.Inject;
import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.teamone.project.dao.ReplyDAO;
import com.teamone.project.model.ReplyModel;

@Repository("reply")
public class ReplyDAOImpl implements ReplyDAO {

	@Inject
	private SqlSession sqlSession;
	
	public void setSqlSession(SqlSession sqlSession){
        this.sqlSession = sqlSession;
    }

	@Override
	public List<ReplyModel> getAllReply() {		
		return sqlSession.selectList("selectAllReply");
	}

	@Override
	public int regReply(ReplyModel model) {
		
		return sqlSession.insert("insertReply", model);
	}

	@Override
	public int getReadCount(String num) {
		return sqlSession.selectOne("selectReadCount", num);
	}

	@Override
	public ReplyModel getReplyDetailsByNum(String num) {
		return sqlSession.selectOne("selectReplyDetailsByNum", num);
	}

	@Override
	public int updateReply(ReplyModel model) {
		return sqlSession.update("updateReply", model);
	}

	@Override
	public ReplyModel checkPassWord(String pass, String num) {
		HashMap<String, String> map = new HashMap<>();
		map.put("pass", pass);
		map.put("num", num);
		return	sqlSession.selectOne("checkPassWord", map);		
	}

	@Override
	public int delReply(String num) {
		return sqlSession.delete("deleteReply", num);
	}

	@Override
	public List<ReplyModel> getReplyList() {
		return sqlSession.selectList("selectReplyList");
	}	
}
