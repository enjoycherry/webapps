package com.teamone.project.dao.impl;

import java.util.List;
import javax.inject.Inject;
import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.teamone.project.dao.MyPageDAO;
import com.teamone.project.model.MyPageModel;

@Repository("myPage")
public class MyPageDAOImpl implements MyPageDAO {

	@Inject
	private SqlSession sqlSession;
	
	public void setSqlSession(SqlSession sqlSession){
        this.sqlSession = sqlSession;
    }

	@Override
	public MyPageModel getMyProfile(String id) {			
		return sqlSession.selectOne("selectMyProfile", id);
	}

	@Override
	public List<MyPageModel> getReplyList(String id) {
		return sqlSession.selectList("selectReplyList", id);
	}	
}
