package com.teamone.project.dao.impl;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.teamone.project.dao.WeatherDAO;
import com.teamone.project.model.WeatherModel;

@Repository("weather")
public class WeatherDAOImpl implements WeatherDAO {

	@Inject
	private SqlSession sqlSession;
	
	public void setSqlSession(SqlSession sqlSession){
        this.sqlSession = sqlSession;
    }

	@Override
	public int regWeather(WeatherModel model) {
		return sqlSession.insert("insertWeather", model);
	}

	@Override
	public int delWeather() {
		return sqlSession.delete("delWeather");
	}

	@Override
	public List<WeatherModel> getWeather() {
		return sqlSession.selectList("selectWeather");
	}    		
}
