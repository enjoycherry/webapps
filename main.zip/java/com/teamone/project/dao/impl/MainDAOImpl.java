package com.teamone.project.dao.impl;

import java.util.List;
import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.teamone.project.dao.MainDAO;
import com.teamone.project.model.MainModel;

@Repository("main")
public class MainDAOImpl implements MainDAO {

	@Inject
	private SqlSession sqlSession;
	
	public void setSqlSession(SqlSession sqlSession){
        this.sqlSession = sqlSession;
    }

	@Override
	public List<MainModel> getNewList() {
		return sqlSession.selectList("selectNewList");
	}   	
}
