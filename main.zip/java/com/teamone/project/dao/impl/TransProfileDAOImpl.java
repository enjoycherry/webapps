package com.teamone.project.dao.impl;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.teamone.project.dao.TransProfileDAO;
import com.teamone.project.model.TransJobModel;
import com.teamone.project.model.TransProfileModel;

@Repository("transProfile")
public class TransProfileDAOImpl implements TransProfileDAO {

	@Inject
	private SqlSession sqlSession;
	
	public void setSqlSession(SqlSession sqlSession){
        this.sqlSession = sqlSession;
    }

	@Override
	public int regTransProfiles(TransProfileModel model) {
		return sqlSession.insert("insertTransProfiles", model);
	}

	@Override
	public List<TransProfileModel> getTransProfileList() {
		return sqlSession.selectList("selectTransProfileList");
	}

	@Override
	public TransProfileModel getTransProfileListByNum(int num) {
		return sqlSession.selectOne("selectTransProfileByNum", num);
	}

	@Override
	public TransProfileModel getTransProfileListById(String id) {
		return sqlSession.selectOne("selectTransProfileById", id);
	}

	@Override
	public TransProfileModel getTransProfileListByCode(int code) {
		return sqlSession.selectOne("selectTransProfileByCode", code);
	}

	@Override
	public int updateTransProfile(TransProfileModel model) {
		return sqlSession.update("updateTransProfile", model);
	}

	@Override
	public List<TransJobModel> getJobList() {
		return sqlSession.selectList("selectJobList");
	}

	@Override
	public List<TransProfileModel> searchTransProfile(String keyword) {
		return sqlSession.selectList("selectTransProfiles", keyword);
	}     	
}
