package com.teamone.project.dao.impl;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.teamone.project.dao.ClientProfileDAO;
import com.teamone.project.model.ClientProfileModel;

@Repository("clientProfile")
public class ClientProfileDAOImpl implements ClientProfileDAO {

	@Inject
	private SqlSession sqlSession;
	
	public void setSqlSession(SqlSession sqlSession){
        this.sqlSession = sqlSession;
    }
     
	@Override
	public int regClientProfile(ClientProfileModel model) {		
		return sqlSession.insert("insertClientProfile", model);
	}		
}
