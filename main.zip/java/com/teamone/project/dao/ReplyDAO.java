package com.teamone.project.dao;

import java.util.List;
import com.teamone.project.model.ReplyModel;

public interface ReplyDAO {
	List<ReplyModel> getAllReply();
	int regReply(ReplyModel model);
	int getReadCount(String num);
	ReplyModel getReplyDetailsByNum(String num);
	int updateReply(ReplyModel model);
	ReplyModel checkPassWord(String pass, String num);
	int delReply(String num);
	List<ReplyModel> getReplyList();
}
