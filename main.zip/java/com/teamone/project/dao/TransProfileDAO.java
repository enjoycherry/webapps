package com.teamone.project.dao;

import java.util.List;
import com.teamone.project.model.TransJobModel;
import com.teamone.project.model.TransProfileModel;

public interface TransProfileDAO {
	int regTransProfiles(TransProfileModel model);
	List<TransProfileModel> getTransProfileList();
	TransProfileModel getTransProfileListByNum(int num);
	TransProfileModel getTransProfileListById(String id);
	TransProfileModel getTransProfileListByCode(int code);
	int updateTransProfile(TransProfileModel model);
	List<TransJobModel> getJobList();
	List<TransProfileModel> searchTransProfile(String keyword);
}
