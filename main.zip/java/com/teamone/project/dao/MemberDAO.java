package com.teamone.project.dao;

import com.teamone.project.model.MemberModel;

public interface MemberDAO {
	int checkUser(String userid, String pwd);
	MemberModel getMemberList(String userid);
	int conrfirmMember(String userid);
	int regMember(MemberModel model);
	int updateMember(MemberModel model);
}
