package com.teamone.project.dao;

import java.util.List;
import com.teamone.project.model.MyPageModel;

public interface MyPageDAO {
	MyPageModel getMyProfile(String id);
	List<MyPageModel> getReplyList(String id);
}
