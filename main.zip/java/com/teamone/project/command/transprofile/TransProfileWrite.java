package com.teamone.project.command.transprofile;

import javax.servlet.http.HttpServlet;

import org.springframework.ui.Model;
import com.teamone.project.command.BCommand;

public class TransProfileWrite extends HttpServlet implements BCommand{

	@Override
	public void execute(Model model) {
		
	}
}