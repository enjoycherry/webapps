package com.teamone.project.command.main;

import org.springframework.ui.Model;
import com.teamone.project.command.BCommand;

public class LoginForm implements BCommand {

	@Override
	public void execute(Model model) {

	}
}
