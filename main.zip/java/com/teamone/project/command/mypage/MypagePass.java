package com.teamone.project.command.mypage;

import org.springframework.ui.Model;
import com.teamone.project.command.BCommand;

public class MypagePass implements BCommand {

	@Override
	public void execute(Model model) {

	}
}
