package com.teamone.project.command.re;

import org.springframework.ui.Model;
import com.teamone.project.command.BCommand;

public class ReView implements BCommand {

	@Override
	public void execute(Model model) {
		
	}
}





