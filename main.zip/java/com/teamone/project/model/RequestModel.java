package com.teamone.project.model;

public class RequestModel {

}
