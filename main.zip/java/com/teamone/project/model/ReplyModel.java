package com.teamone.project.model;

import java.sql.Date;
import java.sql.Timestamp;

public class ReplyModel {
	private int num;
	private String pass; //
	private String name; //
	private String userid; //
	private String email; //
	private String title; //
	private String language; //
	private String content; //
	private String refile; //
	private Date deadline; //
	private String cash; //
	private int readcont;
	private Timestamp wrirdate;
	private String now;

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getRefile() {
		return refile;
	}

	public void setRefile(String refile) {
		this.refile = refile;
	}

	public Date getDeadline() {
		return deadline;
	}

	public void setDeadline(Date deadline) {
		this.deadline = deadline;
	}

	public String getCash() {
		return cash;
	}

	public void setCash(String cash) {
		this.cash = cash;
	}

	public int getReadcont() {
		return readcont;
	}

	public void setReadcont(int readcont) {
		this.readcont = readcont;
	}

	public Timestamp getWrirdate() {
		return wrirdate;
	}

	public void setWrirdate(Timestamp wrirdate) {
		this.wrirdate = wrirdate;
	}

	public String getNow() {
		return now;
	}

	public void setNow(String now) {
		this.now = now;
	}
}